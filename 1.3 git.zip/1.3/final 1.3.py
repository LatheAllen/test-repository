from Tkinter import *
WIDTH = 600
HEIGHT = 800
class App(Tk):
	def __init__(self, *args, **kwargs):
		Tk.__init__(self, *args, **kwargs)
		#create and configure a frame
		container = Frame(self)
		container.pack(side = "top", fill = "both", expand = True)
		container.grid_rowconfigure(0, weight = 1)
		container.grid_columnconfigure(0, weight = 1)

		self.frames = {}

		for F in (StartPage, HomePage, UserPage, SettingsPage, SignInPage):
			frame = F(container, self)
			self.frames[F] = frame
			frame.grid(row = 0, column = 0, sticky = "nsew")
		self.show_frame(SignInPage) #select initially displayed page
	def show_frame(self, context):
		frame = self.frames[context]
		frame.tkraise()

class HomePage(Frame):
	def __init__(self, parent, controller):
		Frame.__init__(self, parent, bg = "#222831")
		#creating widgets
		jumpToStartPageButton = Button(self, text = "<",\
			font = ("Arial", 22), bd = 0, width = WIDTH/250, bg = "#222831", fg="white",\
			command = lambda : controller.show_frame(StartPage))
		header = Label(self, text = "Home", font = ("Arial", 26), bg = "#222831",\
			width = int(0.75*WIDTH), fg = "white")
		calendar = Listbox(self,  bg = "#393e46", width = WIDTH, height = HEIGHT-100, font = ("Arial", 20), fg = "white")
		#put some contents into calendar
		calendar_information = {} #calendar will be dictionary of date : information
		with open("calendar.txt", "rt") as c:
			for line in c:
				line = line.strip()
				line = line.split("|")
				string = ""
				for i in range(1, len(line)-1):
					string += "{}{}".format(line[i], " ")
				string+=line[len(line)-1] #this way there isn't an extra space at end of string
				calendar_information[line[0]] = string
			print calendar_information
		#we want the calendar to be able to display a few things:
			#dates
			dates = calendar_information.keys()
			dates.sort() #we want our dates to be in order
			#event descriptions
			descriptions = []
			#people associated with event
			people = []
			#for this we will have to look at the file staff.txt
			with open("staff.txt", "rt") as s:
				for line in s:
					line = line.strip()
					people.append(line)
			print people
			#since dates will be in order, we will also get descriptions in chronological order
			for x in range(0, len(dates)):
				#get the string associated with the date
				rawText = calendar_information[dates[x]]
				#find out when the actual description starts, as marked by an @ symbol
				descriptionStartIndex = rawText.index("@")
				#get just the description text
				actualDescription = rawText[descriptionStartIndex+1:len(rawText)]
				#add it to a list of descriptions to later match with the date
				descriptions.append(actualDescription)
			print dates
			print descriptions
			for i in range(len(dates)):
				calendarSize=calendar.size()
				#max character length for a line is 39 before it goes off page.
				if len("{}: {}".format(dates[0], descriptions[0])) >= 39:
					firstLine = "{}: {}".format(dates[0], descriptions[0])
					calendar.insert(calendarSize, firstLine[0:39])
					calendar.insert(calendarSize+1, firstLine[39:len(firstLine)])
					calendar.insert(calendarSize, " ")
				else:
					#if the date and the description combined are not long enough to cause
					#the description to go off the screen, just insert them as are.
					calendar.insert(calendarSize, "{}: {}".format(dates[i], descriptions[i]))
					#now, on a new line, list all the people involved with that date
					associatedPeople = []
					for p in range(len(calendar_information)):
						if people[p] in calendar_information[dates[p]]:
							associatedPeople.append(people[p])
					calendar.insert(calendarSize+1, "People: {}".format(associatedPeople[0:len(associatedPeople)+1]))
			#how many days until event listing
			#time of day (as in 3:00pm-6:00pm)
			#related personnel
		#packing widgets
		jumpToStartPageButton.pack(padx = 10, pady = 10, side = LEFT)
		header.pack(padx = 10, pady = 10, side = TOP)
		calendar.pack(padx = 10, pady = 10)

class UserPage(Frame):
	def __init__(self, parent, controller):
		Frame.__init__(self, parent, bg = "#222831")
		#creating widgets
		jumpToStartPageButton = Button(self, text = "<",\
			font = ("Arial", 22), bd = 0,\
			command = lambda : controller.show_frame(StartPage))
		header = Label(self, text = "User", font = ("Arial", 26)) #replace via text file at later point
		#packing widgets
		jumpToStartPageButton.pack(padx = 10, pady = 10, side = LEFT)
		header.pack(padx = 10, pady = 10, side = TOP)
class SettingsPage(Frame):
	def __init__(self, parent, controller):
		Frame.__init__(self, parent, bg = "#222831")
		#creating widgets
		jumpToStartPageButton = Button(self, text = "<",\
			font = ("Arial", 22), bd = 0,\
			command = lambda : controller.show_frame(StartPage))
		header = Label(self, text = "Settings", font = ("Arial", 26)) #replace via text file at later point
		#packing widgets
		jumpToStartPageButton.pack(padx = 10, pady = 10, side = LEFT)
		header.pack(padx = 10, pady = 10, side = TOP)
class SignInPage(Frame):
	def __init__(self, parent, controller):
		Frame.__init__(self, parent, bg = "#222831")
		#used to update StartPage after login confirmation
		#sign in boxes and labels
		self.userNameEntryLabel = Label(self, text = "Username: ", bg = "#222831", fg = "white", font = ("Arial", 22))
		self.userNameEntry = Entry(self, bg = "#393e46", width = int(0.8*WIDTH), font = ("Arial", 20), fg = "white")
		self.passWordEntryLabel = Label(self, text = "Password: ", bg = "#222831", fg = "white", font = ("Arial", 22))
		self.passWordEntry = Entry(self, bg = "#393e46", width = int(0.8*WIDTH), font = ("Arial", 20), fg = "white", show = "*")
		signInButton = Button(self, text = "Sign-In",\
			anchor = W, width = (WIDTH - 400), font = ("Arial", 22),\
			bd = 0, bg = "#222831", fg = "white", activebackground = "#d65a31",
			activeforeground = "white",\
			command = self.validateCredentials)
		label = Label(self, text = "Sign-In", font = ("Arial", 26), bg = "#222831", fg = "white")
		label.pack(padx = 10, pady = 30)
		self.userNameEntryLabel.pack(padx=50, pady=10)
		self.userNameEntry.pack(padx=50, pady=10)
		self.passWordEntryLabel.pack(padx=50, pady=10)
		self.passWordEntry.pack(padx=50, pady=10)
		signInButton.pack(padx = 50, pady = 10)
	def validateCredentials(self):
		credentials = {} #create a dictionary to later pair user and pass
		with open("credentials.txt", "rt") as f: 
			for line in f:
				line = line.strip()
				line = line.split(":")
				credentials[line[0]] = line[1] #username : password
		username = self.userNameEntry.get() #retrieve username and
		password = self.passWordEntry.get() #password as entered by user
		L = credentials.keys()
		if username in L:
			if credentials[username] == password:
				App.show_frame(app, StartPage)


class StartPage(Frame):
	def __init__(self, parent, controller):
		Frame.__init__(self, parent, bg = "#222831")
		jumpToHomePageButton = Button(self, text = "Home",\
			anchor = W, width = (WIDTH - 400), font = ("Arial", 22),\
			bd = 0, bg = "#222831", fg = "white", activebackground = "#d65a31",
			activeforeground = "white",\
			command = lambda : controller.show_frame(HomePage))
		self.jumpToUserPageButton = Button(self, text = "Me",\
			anchor = W, width = (WIDTH - 400), font = ("Arial", 22),\
			bd = 0, bg = "#222831", fg = "white", activebackground = "#d65a31",\
			activeforeground = "white",\
			command = lambda : controller.show_frame(UserPage))
		jumpToSettingsPageButton = Button(self, text = "Settings",\
			anchor = W, width = (WIDTH - 400), font = ("Arial", 22),\
			bd = 0, bg = "#222831", fg = "white", activebackground = "#d65a31",\
			activeforeground = "white",\
			command = lambda : controller.show_frame(SettingsPage))
		label = Label(self, text = "Navigation", font = ("Arial", 26), bg = "#222831", fg = "white")
		label.pack(padx = 10, pady = 30)
		jumpToHomePageButton.pack(padx = 50, pady = 10)
		self.jumpToUserPageButton.pack(padx = 50, pady = 10)
		jumpToSettingsPageButton.pack(padx = 50, pady = 10)



app = App()
app.geometry("{}x{}".format(WIDTH, HEIGHT))
app.mainloop()


