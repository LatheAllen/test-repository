dictionary = {}
people = ["D", "C", "L"]
description = "Calendar started"
dictionary["4/23"] = [people, description]
print dictionary
