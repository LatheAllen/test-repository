from Tkinter import *
WIDTH = 600
HEIGHT = 800
class App(Tk):
	def __init__(self, *args, **kwargs):
		Tk.__init__(self, *args, **kwargs)
		#create and configure a frame
		container = Frame(self)
		container.pack(side = "top", fill = "both", expand = True)
		container.grid_rowconfigure(0, weight = 1)
		container.grid_columnconfigure(0, weight = 1)

		self.frames = {}

		for F in (StartPage, HomePage, UserPage):
			frame = F(container, self)
			self.frames[F] = frame
			frame.grid(row = 0, column = 0, sticky = "nsew")
		self.show_frame(StartPage)
	def show_frame(self, context):
		frame = self.frames[context]
		frame.tkraise()

class StartPage(Frame):
	def __init__(self, parent, controller):
		Frame.__init__(self, parent, bg = "#222831")
		jumpToPageOneButton = Button(self, text = "Home",\
			anchor = W, width = (WIDTH - 400), font = ("Arial", 22),\
			bd = 0, bg = "#222831", fg = "white", activebackground = "#d65a31",
			activeforeground = "white",\
			command = lambda : controller.show_frame(HomePage))
		jumpToPageTwoButton = Button(self, text = "User",\
			anchor = W, width = (WIDTH - 400), font = ("Arial", 22),\
			bd = 0, bg = "#222831", fg = "white", activebackground = "#d65a31",\
			activeforeground = "white",\
			command = lambda : controller.show_frame(UserPage))
		label = Label(self, text = "Navigation", font = ("Arial", 26), bg = "#222831", fg = "white")
		label.pack(padx = 10, pady = 30)
		jumpToPageOneButton.pack(padx = 50, pady = 10)
		jumpToPageTwoButton.pack(padx = 50, pady = 10)

class HomePage(Frame):
	def __init__(self, parent, controller):
		Frame.__init__(self, parent, bg = "#222831")
		#creating widgets
		jumpToStartPageButton = Button(self, text = "<",\
			font = ("Arial", 22), bd = 0,\
			command = lambda : controller.show_frame(StartPage))
		header = Label(self, text = "Home", font = ("Arial", 26))
		calendar = Listbox(self,  bg = "#393e46")
		#put some contents into calendar
		calender_information
		calender_lines = []
		with open ("calendar.txt", "rt") as calender_information:
			for 
		#packing widgets
		jumpToStartPageButton.pack(padx = 10, pady = 10, side = LEFT)
		header.pack(padx = 10, pady = 10, side = TOP)
		calendar.pack(padx = 10, pady = 10)

class UserPage(Frame):
	def __init__(self, parent, controller):
		Frame.__init__(self, parent, bg = "#222831")
		#creating widgets
		jumpToStartPageButton = Button(self, text = "<",\
			font = ("Arial", 22), bd = 0,\
			command = lambda : controller.show_frame(StartPage))
		header = Label(self, text = "User", font = ("Arial", 26)) #replace via text file at later point
		#packing widgets
		jumpToStartPageButton.pack(padx = 10, pady = 10, side = LEFT)
		header.pack(padx = 10, pady = 10, side = TOP)

app = App()
app.geometry("{}x{}".format(WIDTH, HEIGHT))
app.mainloop()

